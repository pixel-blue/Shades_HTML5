Projet en HTML5 d'un tétris simplifié, réalisé par Josua Modoux, Geoffrey Veyre et Cécile Valette, groupe 2G1 de l'IUT Informatique de Bourg en Bresse

https://github.com/pixel-blue/Shades_HTML5