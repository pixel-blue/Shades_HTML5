function getRandomInt(min, max) {
  return Math.floor(Math.random() * (max - min +1)) + min;
}
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                             PARTIE ANIMATION                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////


//// IL MANQUE :
// FUSION CASCADE + FUSION LIGNE
// SCORE
// VERIF POUR LES DEPLACEMENTS DROITE / GAUCHE 




var myGamePiece;
ListeGamePiece =new Array();
var GamePieceindex;
Color=["#DAE1F4","#9CCAEF","#369BDC","#145ABF","#161640"];


var myGameArea = {
    canvas : document.createElement("canvas"),
    start : function() {
        this.x=0;
        this.y=0;
        this.canvas.width = $(window).width();
        this.canvas.height = $(window).height();
        this.context = this.canvas.getContext("2d");
        document.body.insertBefore(this.canvas, document.body.childNodes[0]);
        this.interval = setInterval(updateGameArea, 20);      
        window.addEventListener('keydown', function (e) {
            myGameArea.key = e.keyCode;
        })
        window.addEventListener('keyup', function (e) {
            myGameArea.key = false;
        })
         window.addEventListener('mousemove', function (e) {
            myGameArea.x = e.pageX;
            myGameArea.y = e.pageY;
            movepos(e.pageX);
        })
         
    },
    stop : function() {
        clearInterval(this.interval);
    },    
    clear : function() {
        this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
    }
}

function component(color, x, y) {
    this.color=color;
    this.width = $(window).width()/4;
    this.height = $(window).height()/10;
    this.x = x;
    this.y = y;    
    this.speedX = 0;
    this.speedY = 2;    
    
    this.update = function() {
        ctx = myGameArea.context;
        ctx.fillStyle = this.color;
        ctx.fillRect(this.x, this.y, this.width, this.height);
    }
    this.newPos = function() {
        this.y += this.speedY;
       
        //this.hitBottom();
        this.hitBox();
    }     
        
    this.hitBox = function() {
        var rockBox = $(window).height() - this.height;
        var index=null;
        for(var i=0; i<ListeGamePiece.length-1;i++){
            if(ListeGamePiece[i].x==this.x){
                if((ListeGamePiece[i].y-ListeGamePiece[i].height)<rockBox){
                    rockBox=ListeGamePiece[i].y-ListeGamePiece[i].height;
                    index=i;
                    
                }
            }          
        }  
        
        if (this.y > rockBox) {
                               
            if(index!=null){
                if(this.color==ListeGamePiece[index].color){
                    for(var i=0;i<Color.length;i++){
                        if(Color[i]==this.color){
                            if(i<4){
                                
                                
                                //FUSION
                                rockBox=rockBox+this.height;
                                
                                //this = new component(Color[i+1],lol,rockBox);
                                ListeGamePiece[index].color=Color[i+1];
                                ListeGamePiece[index].update();
                                
                                
                                               
                                console.log(ListeGamePiece[index].y);
                                ListeGamePiece.splice(ListeGamePiece.length-1,1);
                                GamePieceindex--;
                                
                                break;
                                
                            }else{
                                 this.y = rockBox;
                                     console.log(this.y);
                            }
                            break;
                        }
                    }
                }
            }else{
                this.y = rockBox;  
                  
            } 
             GenereObj(); 
        }
    }
}


/// FONCTION CONTROLES : déplacements du block
function moveleft() {
    if(ListeGamePiece[ListeGamePiece.length-1].x>0){
        ListeGamePiece[ListeGamePiece.length-1].x -= ListeGamePiece[ListeGamePiece.length-1].width;   
    }
}

function moveright() {
    if(ListeGamePiece[ListeGamePiece.length-1].x<$(window).width()-ListeGamePiece[ListeGamePiece.length-1].width){
        
        ListeGamePiece[ListeGamePiece.length-1].x += ListeGamePiece[ListeGamePiece.length-1].width;
    }
}

    

function movepos(x) {

    
        if(x < ($(window).width()/4)){
            console.log("1er quart");
            ListeGamePiece[ListeGamePiece.length-1].x = 0;   
            console.log(ListeGamePiece[ListeGamePiece.length-1].x);
        }else if(x < ($(window).width()/2) && x > ($(window).width()/4)){
            console.log("2eme quart");
            ListeGamePiece[ListeGamePiece.length-1].x = $(window).width()/4;   
            console.log(ListeGamePiece[ListeGamePiece.length-1].x);
        }else if(x < ($(window).width()-$(window).width()/4) && x > ($(window).width()/2)){
            console.log("3eme quart");
            ListeGamePiece[ListeGamePiece.length-1].x = $(window).width()/2; 
            console.log(ListeGamePiece[ListeGamePiece.length-1].x);
        }else{
            console.log("3eme quart");
            ListeGamePiece[ListeGamePiece.length-1].x = $(window).width()/2 + $(window).width()/4;
            console.log(ListeGamePiece[ListeGamePiece.length-1].x);
        }

}


function GenereObj(){
    var NewObj;
    NewObj=new component(Color[getRandomInt(0,4)],getRandomInt(0,3)*$(window).width()/4,0);
    ListeGamePiece.push(NewObj);
    GamePieceindex++;
}

///////////////////////// GESTION PARTIE \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

function startGame() {
    myGameArea.start();
    GamePieceindex=0;
    myGamePiece = new component( Color[0], getRandomInt(0,3)*$(window).width()/4, 0);
    ListeGamePiece.push(myGamePiece);
    $('canvas').css('background-color', '#333333');
}


function updateGameArea() {
     if (myGameArea.key && myGameArea.key==37) {
        moveleft();
    }
    if (myGameArea.key && myGameArea.key==39) {
        moveright();
    }
    if (myGameArea.touchX && myGameArea.touchY) {
        console.log(myGameArea.x);
        console.log(myGameArea.y);
    }
    
    
    myGameArea.clear();
    
    
    for(var i=GamePieceindex; i<ListeGamePiece.length;i++){
        ListeGamePiece[i].newPos(); 
    }
    for(var i=0; i<ListeGamePiece.length;i++){
        
        ListeGamePiece[i].update();
    }
    
    //TEST ET DESTRUCTION D'UNE LIGNE DE MEME COULEUR
    for(var j=0; j<ListeGamePiece.length;j++){
            
        var Countligne=0;
        for(var i=0; i<ListeGamePiece.length;i++){
            if(ListeGamePiece[j].x != ListeGamePiece[i].x && ListeGamePiece[j].y > ListeGamePiece[i].y-5 && ListeGamePiece[j].y < ListeGamePiece[i].y+5 && ListeGamePiece[j].color == ListeGamePiece[i].color){
                Countligne++;                
            }
        }
        if(Countligne==3){
            var Suppr1=null;
            var Suppr2=null;
            var Suppr3=null;
            for(var i=0; i<ListeGamePiece.length;i++){
                console.log(i);
                if(ListeGamePiece[j].x != ListeGamePiece[i].x && ListeGamePiece[j].y > ListeGamePiece[i].y-5 && ListeGamePiece[j].y < ListeGamePiece[i].y+5 && ListeGamePiece[j].color == ListeGamePiece[i].color){
                   console.log(i+" "+ListeGamePiece[i]);
                    if(Suppr1==null){
                        Suppr1=i;
                    }else if(Suppr2==null){
                        Suppr2=i;
                    }else if(Suppr3==null){
                        Suppr3=i;
                    }
                }
            }
            
            console.log(j+" "+ListeGamePiece[j]);
            ListeGamePiece.splice(Suppr3,1);
             GamePieceindex--;
            ListeGamePiece.splice(Suppr2,1);
             GamePieceindex--;
            ListeGamePiece.splice(Suppr1,1);
             GamePieceindex--;
            ListeGamePiece.splice(j,1);
             GamePieceindex--;
            GenereObj();
        }
    }
    //////// FIN DESTRUCTION LIGNE
    
    
    // FUSION DE BLOCK DE MEME COULEUR
    
    
    
}







